*******************************************************
*  Name      :  Raechana(Rae) Hong        
*  Student ID:  103939910               
*  Class     :  CSCI 3453           
*  Lab#      :  1                
*  Due Date  :  September 11, 2019
*******************************************************


                 Read Me


*******************************************************
*  Description of the program
*******************************************************

The program reads the system information about the machine.

*******************************************************
*  Source files
*******************************************************

Name:  Lab1A.cpp
   Main program. Reads the system information which are 
the system name, node name, release, version, and machine.

*******************************************************
*  Circumstances of programs
*******************************************************

   The program runs in CSEgrid.
   
