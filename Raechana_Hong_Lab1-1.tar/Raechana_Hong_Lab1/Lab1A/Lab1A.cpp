/*Raechana Hong
 * 103939910
 * Lab 1 Part A
 * Due: September 11, 2019
 */
#include <iostream>
#include <sys/utsname.h>

using namespace std;

int main()
{
	struct utsname utsdata;

	uname(&utsdata);

	cout << "System name - " << utsdata.sysname << endl;
	cout << "Nodename - " << utsdata.nodename << endl;
	cout << "Release - " << utsdata.release << endl;
	cout << "Version - " << utsdata.version << endl;
	cout << "Machine - " << utsdata.machine << endl;

}