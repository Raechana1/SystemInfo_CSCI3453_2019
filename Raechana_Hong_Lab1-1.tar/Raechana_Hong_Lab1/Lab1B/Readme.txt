*******************************************************
*  Name      :  Raechana(Rae) Hong        
*  Student ID:  103939910               
*  Class     :  CSCI 3453           
*  Lab#      :  1                
*  Due Date  :  September 11, 2019
*******************************************************


                 Read Me


*******************************************************
*  Description of the program
*******************************************************

The program reads the system information from the machine.

*******************************************************
*  Source files
*******************************************************

Name:  Lab1B.cpp
   Main program. Reads the system information which are 
last boot time and date, time since last boot, user mode
time and system mode time spent, total memory and memory
available.

*******************************************************
*  Circumstances of programs
*******************************************************

   The program runs in CSEgrid.
   
