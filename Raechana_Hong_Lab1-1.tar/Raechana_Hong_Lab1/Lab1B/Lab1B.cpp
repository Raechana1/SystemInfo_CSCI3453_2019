/*Raechana Hong
 * 103939910
 * Lab 1 Part B
 * Due: September 11, 2019
 */

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iterator>
#include <vector>
#include <time.h>

using namespace std;

int main() {
	ifstream file("/proc/stat");
	string str, str1;
	struct tm ts;
	char buf[80];
	time_t u;

	while (getline(file, str)) {
		if (str.find("btime") != string::npos) {
			istringstream iss(str);
			vector<string> results((istream_iterator<string>(iss)), istream_iterator<string>());
			u = stoul(results[1], nullptr, 0);
			ts = *localtime(&u);
			strftime(buf, sizeof(buf), "%F %T", &ts);
			cout << "Last Boot Time: \t" << buf << endl;			
		}
	}


	ifstream file2("/proc/uptime");
	while(file2 >> str >> str1){
		u = stoul(str, nullptr, 0);
		ts = *localtime(&u);
		strftime(buf, sizeof(buf), "%d:%T", &ts);
		cout << "Time Since Last Boot: \t" << buf << endl;	
	}

	ifstream file3("/proc/stat");
	string word;
	vector<string> buf2;
	for(int i = 0; i < 5; i++){
		file3 >> word;
		buf2.push_back(word);	
	}
	
	cout << "User Mode: \t\t";
	u = stoul(buf2[1], nullptr, 0);
	ts = *localtime(&u);
	strftime(buf, sizeof(buf), "%T", &ts);
	cout << buf << endl;

	cout << "System Mode: \t\t";
	u = stoul(buf2[3], nullptr, 0);
	ts = *localtime(&u);
	strftime(buf, sizeof(buf), "%T", &ts);
	cout << buf << endl;	

	ifstream file4("/proc/meminfo");
	while(getline(file4, str)){
		if (str.find("MemTotal") != string::npos) {
			cout << str << endl;
		}
		if(str.find("MemAvailable") != string::npos){
			cout << str << endl;
		}
	}
	
}